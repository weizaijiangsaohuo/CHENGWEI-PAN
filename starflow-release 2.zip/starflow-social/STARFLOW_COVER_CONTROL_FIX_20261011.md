# Starflow AI · 个人主页「更换封面」按钮可见性修复（2026-10-11）

## 现场问题

手机个人主页中，更换封面的控件出现在封面底边，恰好被 `profile-info` 的负外边距叠层遮盖，呈现半透明、文字模糊，并贴近下方「编辑资料」按钮。

## 本次修复

- 将更换封面的可见按钮固定至**封面右上角**，离开个人资料的覆盖区域。
- 深色实底、白色图标和文字、至少 42px 高度；手机端按钮保持醒目且有触控面积。
- 整块封面维持可点击更换，不改变现有 `input[type=file]`、头像上传、服务端权限校验、Supabase 存储或页面跳转。
- 不新增数据库、表、存储桶或外部依赖；保留已上线的所有组件与现有资料。

## ZIP 更新文件

1. `starflow-social/app/layout.tsx`：在其他样式之后导入新的封面控制样式（现有组件及 import 全部保留）。
2. `starflow-social/app/profile-cover-controls.css`：独立覆盖封面控件位置和对比度。
3. `starflow-social/STARFLOW_COVER_CONTROL_FIX_20261011.md`：本说明。

将 ZIP 作为仓库根目录 **`starflow-release.zip`** 覆盖旧包；仓库现有 Actions 执行解压、类型检查、构建后提交源码。

## 检验

1. 等 GitHub ZIP Auto Update、Code Check 和新源码提交的 Cloudflare Workers Builds 全部成功。
2. iPhone Safari 刷新个人主页，确认右上方深色「更换封面」按钮**完全落在封面图内**且清晰可读。
3. 点击按钮（或封面空白处）是否可以选择照片，确认「编辑资料」按钮仍可独立点击。
4. 查看其他用户个人主页时不显示相机编辑按钮；既有头像和帖子保持不变。

注意：离线 ZIP / CSS 检查不等于上线或真实用户验收，必须待 Actions 和 Cloudflare 构建完成后实测。
